var http = require('http'),
    Buffer = require('buffer').Buffer;
var resProto = http.ServerResponse.prototype;

var puts = require("sys").puts;


var Server = require("./connect").Server;


var connectApp = new Server([
{module: {
        handle: function(req, res){
            res.writeHead(200,{});
            res.end("hello world");
        }}}
]);
var connectWithMiddleWare = new Server([
{module: {
        handle: function(req, res, next){
        	next();
        }}},
{module: {
        handle: function(req, res, next){
        	next();
        }}},
{module: {
        handle: function(req, res, next){
        	next();
        }}},
{module: {
        handle: function(req, res, next){
        	next();
        }}},
{module: {
        handle: function(req, res, next){
        	next();
        }}},
{module: {
        handle: function(req, res, next){
        	next();
        }}},
{module: {
        handle: function(req, res, next){
        	next();
        }}},
{module: {
        handle: function(req, res, next){
        	next();
        }}},
{module: {
        handle: function(req, res, next){
        	next();
        }}},
{module: {
        handle: function(req, res){
            res.writeHead(200,{});
            res.end("hello world");
        }}}
]);
var request = {
	method: "GET",
	url: "http://localhost/test.js"
};
	
var response = {
	writeHead: function(){},
	write: function(){},
	end: function(){}
};
var startTime = new Date().getTime();
for(var i = 0; i < 100000; i++){
	connectWithMiddleWare.handle(request, response);
}
puts(100000000 / (new Date().getTime() - startTime));


jsgiNode = require("../../packages/jsgi-node/lib/jsgi-node");

JSGI = function(next){
	return function(request){
		return next(request);
	}
}
var jsgiApp = function(){
	return {
		status:200,
		body: ["hello world"],
		headers:{}
	}
};
var jsgiAppWithMiddleWare = JSGI(JSGI(JSGI(JSGI(JSGI(JSGI(JSGI(JSGI(JSGI(jsgiApp)))))))));
var nodeJsgiApp = jsgiNode.Listener(jsgiAppWithMiddleWare);

var startTime = new Date().getTime();
for(var i = 0; i < 1000000; i++){
	nodeJsgiApp(request, response);
}
puts(1000000000 / (new Date().getTime() - startTime));
